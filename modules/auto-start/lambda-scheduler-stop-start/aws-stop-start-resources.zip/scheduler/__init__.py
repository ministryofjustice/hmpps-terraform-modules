"""Module containing the logic for the lambda scheduler entry-points."""
